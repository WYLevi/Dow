from threading import Thread
from collections import deque
from multiprocessing import Process
import cv2
import time

def producer(cap, q, camera_index, f, startminute, startsecond, e_m, e_s):
	nowsecond = 0
	frame = 0
	while True:
		try:
			localtime = time.localtime()
			ret = cap.grab()
			framesecond = time.strftime("%S", localtime)

			if not ret:
				print("camera {} error".format(camera_index))
			else:
				frame += 1
			if frame % (15/3) == 0:
				ret, img = cap.retrieve()
				q.append(img)
				nowsecond = framesecond
				f.append(frame)
				end = time.localtime()
				endminute = time.strftime("%M", end)
				endsecond = time.strftime("%S", end)
				e_m.append(endminute)
				e_s.append(endsecond)
				#print(frame, "producer")
			if frame >= 450:
				break
		except:
			print("camera {} error".format(camera_index))
def consumer(camera_index, outVideo, q, f, startminute, startsecond, e_m, e_s):
	print("Start to capture and save video of camera {}...".format(camera_index))
	count = 0
	while True:
		#print(len(q))
		try:
			if len(q) == 0:
				pass
			elif 0xFF == 27:
				break
			else:
				# count += 1
				img = q.pop()
				frame = f.pop()
				endminute = e_m.pop()
				endsecond = e_s.pop()
				#cv2.namedWindow("camera {}".format(camera_index),0)
				outVideo.write(img)
				if frame >= 450:
					break
				#print("consumer")
		except:
			print("camera {} error".format(camera_index))

def multithread_run(camera_index, url, num):
	# get size and fps of video
	width =  1280
	height = 720
	fps = 15
	fourcc = cv2.VideoWriter_fourcc('M','P','4','2')
	#fourcc = 0x00000021
	# fourcc = cv2.VideoWriter_fourcc(*'mp4v')
	#fourcc = cv2.VideoWriter_fourcc(*'MP4V')
	# create VideoWriter for saving
	outVideo = cv2.VideoWriter('Video_save_{}_{}.avi'.format(camera_index, num), fourcc, fps, (width, height))
	q = deque(maxlen=1)
	f = deque(maxlen=1)
	start = time.localtime()
	startminute = time.strftime("%M", start)
	startsecond = time.strftime("%S", start)
	e_s = deque(maxlen=1)
	e_m = deque(maxlen=1)
	cap = cv2.VideoCapture(url)	
	width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
	height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
	print("Frame Width = {}, Frame Height = {}".format(width, height))
	#time.sleep(10)
	frame = 0
	p1 = Thread(target=producer, args=(cap, q, camera_index, f, startminute, startsecond, e_m, e_s))
	c1 = Thread(target=consumer, args=(camera_index, outVideo, q, f, startminute, startsecond, e_m, e_s))
	p1.start()  
	c1.start()
	p1.join()
	c1.join()

if __name__ == "__main__":
	num = 0
	while True:
		processes = []
		nloops = range(5)

		#Assume that the two camera IPs are 192.168.9.151 and 192.168.9.152
		url = 'rtsp://192.168.137.{}/h265'
		# url = 'rtsp://admin:12345@10.180.9.122'
		camera_index = 86

		for i in nloops:
				#t = Process(target=multithread_run, args=(camera_index+i, url.format(camera_index+i),num))
				t = Process(target=multithread_run, args=(camera_index+i, url.format(camera_index+i),num))
				processes.append(t)

		for i in nloops:
			processes[i].start()
			print("start")

		for i in nloops:
			processes[i].join()
			print("join")
		num+= 1
	
		
