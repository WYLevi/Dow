import json
from suds.client import Client
import cv2
import base64

def CV2Base64(img): 
    base64Str = base64.b64encode(cv2.imencode('.jpg', img)[1]).decode()
    return str(base64Str)

def LinkSOAP(url, string):
    client = Client(url)
    replycode = client.service.PublishEvent(string)
    if str(type(replycode)) != "<class 'NoneType'>":
        if len(replycode) > 0:
            return json.loads(replycode)
        else:
            return 'Link no reply'
    else:
        return 'Link no reply'

def Linkpost(img):
    url = 'http://au6ifs02/angelia/Prod/EventPlusWS/EventPlusAPI.asmx?WSDL'
    subCateNo = "3241"
    systemCode = "396hLng7S4"
    linkTitle = 'L3B - A區 - 環安偵測異常'
    linkMsg = '貨高超過2公尺 - 貨物已越線'
    ### show image information
    #img = cv2.imread('./CAM_6_Fail.jpg')
    base64String = CV2Base64(img)
    linkPost = f'''
                    {{'FunctionName':'PublishEvent',
                    'SystemCode':'{systemCode}',
                    'SubCateNo':'{subCateNo}',
                    'EventContent':'{linkTitle}<br />{linkMsg}',
                    'FixedAppendInfo':'value',
                    'HasAttachedImage':true,
                    'AttachedImages':[{{'Base64ImageContent':'{base64String}'}}]}} '''
    linkPost = linkPost.replace('\n', '')
    
    # try:
    replyCode = LinkSOAP(url, linkPost)
    if type(replyCode) == dict:
        if replyCode['ReturnMsg'] == 'Success':
            print(f"reply:{replyCode['ReturnMsg']}")
        else:
            print(f"reply:{replyCode['ReturnMsg']}")
    else:
        print(replyCode)
            
            
# if __name__ == '__main__':

#     main()
