

import cv2, os
import numpy as np
from skimage.metrics import structural_similarity
import configparser
import time

def find_lefttop_patch(coor, step):
    '''
    find the first full patch from left-top
    '''
    while(1):
        match_min = coor
        coor = coor - step
        if coor < 0:
            return match_min

def load_img(img):
    '''
    load image -> make the left-top mask -> 
    resize to original size -> generate the gray -> find the center
    '''
    #cv2.rectangle(img, (0, 0), (196, 138), 0, -1)
    #img = cv2.resize(img, (1080, 900))
    img = cv2.imread(img)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_gray = cv2.GaussianBlur(img_gray, (5, 5), 0)
    img_center = (img.shape[0]/2, img.shape[1]/2)
    return img, img_gray, img_center

def ssim(org_img,new_img,source):
    t1 = time.time()
    ori_img, ori_img_gray, ori_img_center = load_img(org_img)
    rec_img_gray = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)
    rec_img_gray=cv2.GaussianBlur(rec_img_gray, (5, 5), 0)

    defect_contours = []
    dif_mask = np.zeros((ori_img_gray.shape[0], ori_img_gray.shape[1], 1), np.uint8)
    violate_mask = np.zeros((ori_img_gray.shape[0], ori_img_gray.shape[1], 1), np.uint8)
    SrvCfg = configparser.ConfigParser()
    SrvCfg.read('./L3Bmask.cfg')

    CAM = os.path.basename(source)[0:6]
    #三種限制區Mask圖
    goodshight = eval(SrvCfg.get(CAM,'goodshight'))
    zebraglue = eval(SrvCfg.get(CAM,'zebraglue'))
    limit = eval(SrvCfg.get(CAM,'limit'))
    goodshight[2], goodshight[3] = goodshight[3], goodshight[2]
    zebraglue[2], zebraglue[3] = zebraglue[3], zebraglue[2]
    limit[2], limit[3] = limit[3], limit[2]
    if CAM != 'CAM_6_' and CAM != 'CAM_7_' and CAM != 'CAM_12':
        limit[0], limit[1] = limit[1], limit[0]
    cv2.fillPoly(violate_mask, [np.array(goodshight), np.array(zebraglue)], (255, 255, 255))
    cv2.fillPoly(violate_mask, [ np.array(limit)], (255, 255, 255))
    # cv2.imshow('dif_mask', dif_mask)
    # cv2.waitKey(0)
    (score_crop, diff_crop) = structural_similarity(ori_img_gray, rec_img_gray, full = True)
    diff_crop = (diff_crop * 255).astype("uint8")
    (_, thresh) = cv2.threshold(diff_crop, 125, 255, cv2.THRESH_BINARY_INV)
    (contours, _) = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for contour in contours:
        if cv2.contourArea(contour) >= 300:
            defect_contours.append(contour )
    cv2.drawContours(dif_mask, defect_contours, -1, 255, thickness = cv2.FILLED)
    #cv2.imshow('dif_mask', dif_mask)
    dif_mask = cv2.dilate(dif_mask,None, iterations = 3)
    dif_mask = cv2.erode(dif_mask, None, iterations = 3)
    #dif_mask = cv2.dilate(dif_mask, None, iterations = 2)
    dif_mask = cv2.cvtColor(dif_mask, cv2.COLOR_GRAY2BGR)
    violate_mask = cv2.cvtColor(violate_mask, cv2.COLOR_GRAY2BGR)
    # cv2.imshow('dif_mask', dif_mask)
    # cv2.waitKey(0)
    dif_mask=cv2.bitwise_and(dif_mask,violate_mask)
    s = np.sum(dif_mask, axis=2)
    non_black = (s != 0)
    x, y = np.where(non_black)
    abnormal=np.stack((y,x),axis=1)
    # cv2.imshow('dif_mask', dif_mask)
    # cv2.waitKey(0)
    # cv2.imwrite('CAM2_ssim.jpg',dif_mask)
    t2 = time.time()
    #print(f'{s}Done. ({t2 - t1:.3f}s)')
    return abnormal
