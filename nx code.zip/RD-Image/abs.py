import cv2
import configparser
import os
import numpy as np

def load_img(img):
    '''
    load image -> make the left-top mask -> 
    resize to original size -> generate the gray -> find the center
    '''
    img = cv2.imread(img)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_gray = cv2.GaussianBlur(img_gray, (5, 5), 0)
    return img_gray

def Abs(img1, img2, goodshight, zebraglue, limit):
    blur2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    blur2 = cv2.GaussianBlur(blur2, (5, 5), 0)
    blur1 = load_img(img1)
    '''建立限制區mask圖'''
    dif_mask = np.zeros((blur1.shape[0], blur1.shape[1], 1), np.uint8)
    violate_mask = np.zeros((blur1.shape[0], blur1.shape[1], 1), np.uint8)
    goodshight[2], goodshight[3] = goodshight[3], goodshight[2]
    zebraglue[2], zebraglue[3] = zebraglue[3], zebraglue[2]
    limit[2], limit[3] = limit[3], limit[2]
    cv2.fillPoly(violate_mask, [np.array(goodshight), np.array(zebraglue)], (255, 255, 255))
    cv2.fillPoly(violate_mask, [ np.array(limit)], (255, 255, 255))

    '''影像相減找出與正常影像不同之處'''
    #影像相減法
    img=cv2.absdiff(blur2,blur1)
    #影像二值化
    ret, th = cv2.threshold( img, 40, 255, cv2.THRESH_BINARY )
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
    dif_mask = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel)
    dif_mask = cv2.cvtColor(dif_mask, cv2.COLOR_GRAY2BGR)
    violate_mask = cv2.cvtColor(violate_mask, cv2.COLOR_GRAY2BGR)

    '''將限制區mask圖與影像相減法做and運算'''
    dif_mask=cv2.bitwise_and(dif_mask, violate_mask)
    s = np.sum(dif_mask, axis=2)
    non_black = (s != 0)
    x, y = np.where(non_black)
    abnormal = np.stack((y,x),axis=1)

    return abnormal