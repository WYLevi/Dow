import cv2
import configparser
import os
import numpy as np
import time

def load_img(img):
    '''
    load image -> make the left-top mask -> 
    resize to original size -> generate the gray -> find the center
    '''
    #cv2.rectangle(img, (0, 0), (196, 138), 0, -1)
    #img = cv2.resize(img, (1080, 900))
    img = cv2.imread(img)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img_gray = cv2.GaussianBlur(img_gray, (5, 5), 0)
    #img_center = (img.shape[0]/2, img.shape[1]/2)
    return img_gray
# #影像轉灰階
# gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
# gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

# # 高斯模糊化處理
# blur1 = cv2.GaussianBlur(gray1,(5,5),0)
# blur2 = cv2.GaussianBlur(gray2,(5,5),0)
def Abs(img1, img2, source, goodshight, zebraglue, limit):
    t1=time.time()
    #print(img1)
    #print(img2)
    #blur2 = load_img(img2)
    blur2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    blur2 = cv2.GaussianBlur(blur2, (5, 5), 0)
    blur1 = load_img(img1)
    dif_mask = np.zeros((blur1.shape[0], blur1.shape[1], 1), np.uint8)
    violate_mask = np.zeros((blur1.shape[0], blur1.shape[1], 1), np.uint8)
    #SrvCfg = configparser.ConfigParser()
    #SrvCfg.read('./L3Bmask.cfg')

    CAM = os.path.basename(source)[0:6]
    #三種限制區Mask圖
    # goodshight = eval(SrvCfg.get(CAM,'goodshight'))
    # zebraglue = eval(SrvCfg.get(CAM,'zebraglue'))
    # limit = eval(SrvCfg.get(CAM,'limit'))
    goodshight[2], goodshight[3] = goodshight[3], goodshight[2]
    zebraglue[2], zebraglue[3] = zebraglue[3], zebraglue[2]
    limit[2], limit[3] = limit[3], limit[2]
    if CAM != 'CAM_6_' and CAM != 'CAM_7_' and CAM != 'CAM_12':
        limit[0], limit[1] = limit[1], limit[0]
    cv2.fillPoly(violate_mask, [np.array(goodshight), np.array(zebraglue)], (255, 255, 255))
    cv2.fillPoly(violate_mask, [ np.array(limit)], (255, 255, 255))


    #影像相減法
    img=cv2.absdiff(blur2,blur1)
    #影像二值化
    ret, th = cv2.threshold( img, 40, 255, cv2.THRESH_BINARY )
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
    dif_mask = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel)
    dif_mask = cv2.cvtColor(dif_mask, cv2.COLOR_GRAY2BGR)
    violate_mask = cv2.cvtColor(violate_mask, cv2.COLOR_GRAY2BGR)
    # cv2.imshow('dif_mask', dif_mask)
    # cv2.waitKey(0)
    dif_mask=cv2.bitwise_and(dif_mask, violate_mask)
    s = np.sum(dif_mask, axis=2)
    non_black = (s != 0)
    x, y = np.where(non_black)
    abnormal = np.stack((y,x),axis=1)
    # cv2.imshow('dif_mask', dif_mask)
    # cv2.waitKey(0)
    # cv2.imwrite('CAM2_ssim.jpg',dif_mask)
    t2 = time.time()
    print(t2-t1)

    return abnormal